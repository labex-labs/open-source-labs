# __init__.py

from .formatter import print_table, create_formatter

__all__ = ["print_table", "create_formatter"]
